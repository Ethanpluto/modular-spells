for stage in range(0,27):
    name = 'stage' + str(stage+1) + '.mcfunction'
    with open(name, 'w') as f:
        data = '''
function modular_spells:link/chest/items

scoreboard players remove @e[tag=chest] maxStage 1
scoreboard players add @e[tag=chest] linkStage 1
execute as @s at @s if entity @e[tag=chest,scores={maxStage=1..}] run function modular_spells:link/chest/stage'''+str(stage+2)+'''
'''
        f.write(data)
