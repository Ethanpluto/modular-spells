#execute if entity @s[scores={stage=1},nbt={Inventory:[{Slot:1b,id:"minecraft:structure_void"}]}] run function modular_spells:test/test
item = input("item name:")
function = input("function name:")


for stage in range(0,8):
    print('execute if entity @s[scores={stage=' + str(stage+1) + '},nbt={Inventory:[{Slot:' + str(stage+1) + 'b,id:"minecraft:' + str(item) + '"}]}] run function modular_spells:' + str(function) + str(stage+1) + '/run')   