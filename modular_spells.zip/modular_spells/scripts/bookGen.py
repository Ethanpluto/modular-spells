import os


for book in range(0,8):
    folder = 'book' + str(book+1)
    os.mkdir(folder)
    
    with open(str(folder)+'/run.mcfunction', 'w') as f:
        data ='''
execute store result score @s maxStage run data get entity @s Inventory[{Slot:'''+str(book+1)+'''b}].tag.pages

function modular_spells:position/'''+str(folder)+'''/stage/1
'''
        f.write(data)
        f.close()
    stage = str(folder) + '/stage'
    os.mkdir(stage)
    for page in range(0,10):
        with open(str(stage)+'/'+str(page+1)+'.mcfunction', 'w') as f:
            data ='''
execute store result score @s move run data get entity @s Inventory[{Slot:'''+str(book+1)+'''b}].tag.pages['''+str(page)+''']

execute if entity @s[scores={move=1..28}] run function modular_spells:position/c1cc
execute if entity @s[scores={move=29..56}] run function modular_spells:position/c-1cc
execute if entity @s[scores={move=58..85}] run function modular_spells:position/cc1c
execute if entity @s[scores={move=86..113}] run function modular_spells:position/cc-1c
execute if entity @s[scores={move=115..142}] run function modular_spells:position/ccc1
execute if entity @s[scores={move=143..170}] run function modular_spells:position/ccc-1

execute if entity @s[scores={move=174..201}] run function modular_spells:position/t1tt
execute if entity @s[scores={move=202..229}] run function modular_spells:position/t-1tt
execute if entity @s[scores={move=231..258}] run function modular_spells:position/tt1t
execute if entity @s[scores={move=259..286}] run function modular_spells:position/tt-1t
execute if entity @s[scores={move=288..315}] run function modular_spells:position/ttt1
execute if entity @s[scores={move=316..343}] run function modular_spells:position/ttt-1

# execute if entity @s[scores={move=347..374}] run function modular_spells:position/r1r
# execute if entity @s[scores={move=375..402}] run function modular_spells:position/r-1r
# execute if entity @s[scores={move=404..431}] run function modular_spells:position/rr1
# execute if entity @s[scores={move=432..459}] run function modular_spells:position/rr-1


scoreboard players remove @s maxStage 1
execute if entity @s[scores={maxStage=1..}] run function modular_spells:position/'''+str(folder)+'''/stage/'''+str(page+2)+'''
'''
            f.write(data)
            f.close()