#replaceitem entity @s[scores={stage=1},nbt={Inventory:[{Slot:1b,id:"minecraft:structure_void",Count:2b}]}] hotbar.1 minecraft:structure_void 1
input = input("item name:")

for stage in range(0,8):
    for count in range(0,64):
        if(count==0):
            print('replaceitem entity @s[scores={stage=' + str(stage+1) + '},nbt={Inventory:[{Slot:' + str(stage+1) + 'b,id:"minecraft:' + str(input) + '",Count:' + str(count+1) + 'b}]}] hotbar.' + str(stage+1) + ' minecraft:air 1')
        else:
            print('replaceitem entity @s[scores={stage=' + str(stage+1) + '},nbt={Inventory:[{Slot:' + str(stage+1) + 'b,id:"minecraft:' + str(input) + '",Count:' + str(count+1) + 'b}]}] hotbar.' + str(stage+1) + ' minecraft:' + str(input) + ' ' + str(count))
