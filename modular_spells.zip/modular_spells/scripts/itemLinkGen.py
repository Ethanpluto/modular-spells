#execute if block ~ ~ ~ #modular_spells:container{Items:[{Slot:0b,id:"minecraft:structure_void"}]} run function modular_spells:test/test
item = input("item name:")
function = input("function name:")


for stage in range(0,27):
    print('execute at @e[tag=chest,tag=loop,scores={linkStage=' + str(stage+1) + '}] if block ~ ~ ~ #modular_spells:container{Items:[{Slot:' + str(stage) + 'b,id:"minecraft:' + str(item) + '"}]} run function modular_spells:' + str(function))   