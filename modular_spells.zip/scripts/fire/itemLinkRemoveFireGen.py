#execute as @e[tag=chest,scores={linkStage=1}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:0b,id:"minecraft:flint_and_steel",Count:1b,tag:{Damage:2}}]} run replaceitem block ~ ~ ~ container.0 minecraft:flint_and_steel{tag:{Damage:1}} 1
item = input("item name:")


for stage in range(26,-1,-1):
    for count in range(63,-1,-1):
        if(count==63):
            print('execute as @e[tag=chest,tag=loop,scores={linkStage=' + str(stage+1) + '}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:' + str(stage) + 'b,id:"minecraft:' + str(item) + '",Count:1b,tag:{Damage:' + str(count) + '}}]} run replaceitem block ~ ~ ~ container.' + str(stage) + ' minecraft:air 1')
        elif(count==0):
            print('execute as @e[tag=chest,tag=loop,scores={linkStage=' + str(stage+1) + '}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:' + str(stage) + 'b,id:"minecraft:' + str(item) + '",Count:1b,tag:{used:0b}}]} run replaceitem block ~ ~ ~ container.' + str(stage) + ' minecraft:' + str(item) + '{Damage:' + str(count+1) + ',used:1b}' + ' 1')
        else:
            print('execute as @e[tag=chest,tag=loop,scores={linkStage=' + str(stage+1) + '}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:' + str(stage) + 'b,id:"minecraft:' + str(item) + '",Count:1b,tag:{Damage:' + str(count) + '}}]} run replaceitem block ~ ~ ~ container.' + str(stage) + ' minecraft:' + str(item) + '{Damage:' + str(count+1) + ',used:1b}' + ' 1')

