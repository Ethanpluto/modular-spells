#replaceitem entity @s[scores={stage=1},nbt={Inventory:[{Slot:1b,id:"minecraft:flint_and_steel",Count:1b,tag:{Damage:2}}]}] hotbar.1 minecraft:flint_and_steel{tag:{Damage:1}} 1
input = input("item name:")

for stage in range(7,-1,-1):
    for count in range(63,-1,-1):
        if(count==63):
            print('replaceitem entity @s[scores={stage=' + str(stage+1) + '},nbt={Inventory:[{Slot:' + str(stage+1) + 'b,id:"minecraft:' + str(input) + '",Count:1b,tag:{Damage:' + str(count) + '}}]}] hotbar.' + str(stage+1) + ' minecraft:air 1')
        elif(count==0):
            print('replaceitem entity @s[scores={stage=' + str(stage+1) + '},nbt={Inventory:[{Slot:' + str(stage+1) + 'b,id:"minecraft:' + str(input) + '",Count:1b,tag:{used:0b}}]}] hotbar.' + str(stage+1) + ' minecraft:' + str(input) + '{Damage:' + str(count+1) + ',used:1b}' + ' 1')
        else:
            print('replaceitem entity @s[scores={stage=' + str(stage+1) + '},nbt={Inventory:[{Slot:' + str(stage+1) + 'b,id:"minecraft:' + str(input) + '",Count:1b,tag:{Damage:' + str(count) + '}}]}] hotbar.' + str(stage+1) + ' minecraft:' + str(input) + '{Damage:' + str(count+1) + ',used:1b}' + ' 1')
