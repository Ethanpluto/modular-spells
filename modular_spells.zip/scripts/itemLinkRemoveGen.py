#execute as @e[tag=chest,scores={linkStage=1}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:0b,id:"minecraft:ender_eye",Count:2b}]} run replaceitem block ~ ~ ~ container.0 minecraft:ender_eye 1
item = input("item name:")


for stage in range(0,27):
    for count in range(0,64):
        if(count==0):
            print('execute as @e[tag=chest,tag=loop,scores={linkStage=' + str(stage+1) + '}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:' + str(stage) + 'b,id:"minecraft:' + str(item) + '",Count:' + str(count+1) + 'b}]} run replaceitem block ~ ~ ~ container.' + str(stage) + ' minecraft:air 1')
        else:
            print('execute as @e[tag=chest,tag=loop,scores={linkStage=' + str(stage+1) + '}] at @s if block ~ ~ ~ #modular_spells:container{Items:[{Slot:' + str(stage) + 'b,id:"minecraft:' + str(item) + '",Count:' + str(count+1) + 'b}]} run replaceitem block ~ ~ ~ container.' + str(stage) + ' minecraft:' + str(item) + ' ' + str(count))

